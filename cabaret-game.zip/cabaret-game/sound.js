const SoundManager = (() => {
  let ctx = null;
  function ac() {
    if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
    return ctx;
  }
  function tone(freq, dur, type = 'sine', vol = 0.22) {
    try {
      const c = ac();
      const osc = c.createOscillator();
      const g = c.createGain();
      osc.connect(g); g.connect(c.destination);
      osc.type = type;
      osc.frequency.value = freq;
      g.gain.setValueAtTime(vol, c.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + dur);
      osc.start(); osc.stop(c.currentTime + dur);
    } catch (e) {}
  }
  return {
    click()  { tone(880, 0.07, 'sine', 0.15); },
    select() { tone(660, 0.08, 'triangle', 0.18); setTimeout(() => tone(880, 0.1, 'triangle', 0.18), 65); },
    drink()  { tone(523, 0.12, 'sine', 0.22); setTimeout(() => tone(784, 0.18, 'sine', 0.22), 105); },
    badEnd() { [200, 180, 155].forEach((f, i) => setTimeout(() => tone(f, 0.7, 'sawtooth', 0.28), i * 370)); },
    happy()  { [523, 659, 784, 1047].forEach((f, i) => setTimeout(() => tone(f, 0.32, 'sine', 0.28), i * 145)); },
    normal() { tone(392, 0.5, 'sine', 0.2); setTimeout(() => tone(349, 0.7, 'sine', 0.16), 420); },
  };
})();
