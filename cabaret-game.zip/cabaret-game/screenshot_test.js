﻿const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ 
    headless: true,
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
  });
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  
  const characters = [
    { name: 'キモオタ', emoji: '🤓', color: '#6655dd',
      url: 'https://api.dicebear.com/8.x/adventurer/svg?seed=kimootaku&glasses=variant01&glassesProbability=100&eyebrows=variant08' },
    { name: 'こどおじ', emoji: '😅', color: '#44aa55',
      url: 'https://api.dicebear.com/8.x/big-smile/svg?seed=kodookoji_mamas_boy' },
    { name: 'イケメンサイコ\n(修正後)', emoji: '😈', color: '#cc4444',
      url: 'https://api.dicebear.com/8.x/lorelei/svg?seed=ikemen_dark_prince' },
    { name: '陰謀論おじさん', emoji: '🧐', color: '#996633',
      url: 'https://api.dicebear.com/8.x/adventurer/svg?seed=conspiracy_uncle_truther&eyebrows=variant12' },
    { name: 'ホスト崩れ\n(修正後)', emoji: '💅', color: '#dd8800',
      url: 'https://api.dicebear.com/8.x/micah/svg?seed=ex_host_charming&hair=fonze&earRings=hoop&earRingsProbability=100&mouth=smirk&hairColor=f9c9b6' },
    { name: 'AI幻想くん', emoji: '🤖', color: '#33bbff',
      url: 'https://api.dicebear.com/8.x/bottts/svg?seed=ai_delusion_kun' },
  ];
  
  const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>最終キャラ確認</title>
  <style>
    body { background: #1a0030; font-family: sans-serif; display: flex; flex-wrap: wrap; gap: 20px; padding: 24px; }
    .card { background: rgba(255,255,255,0.07); border-radius: 14px; padding: 18px; text-align: center; width: 175px; }
    .avatar { width: 120px; height: 120px; border-radius: 50%; margin: 0 auto 10px; display: flex; align-items: center; justify-content: center; font-size: 48px; overflow: hidden; }
    .avatar img { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; }
    .name { color: white; font-size: 13px; font-weight: bold; white-space: pre-line; }
    .style { color: #aaa; font-size: 10px; margin-top: 4px; }
  </style>
</head>
<body>
${characters.map(c => `
  <div class="card">
    <div class="avatar" style="background:${c.color}44;border:3px solid ${c.color}">
      <img src="${c.url}" alt="${c.name}" onerror="this.parentElement.innerHTML='${c.emoji}'">
    </div>
    <div class="name">${c.name}</div>
    <div class="style">${c.url.match(/8\.x\/([^/]+)/)[1]}</div>
  </div>
`).join('')}
</body>
</html>`;
  
  await page.setContent(html);
  await page.waitForLoadState('networkidle');
  await page.waitForTimeout(5000);
  await page.screenshot({ path: 'screenshot_final.png', fullPage: true });
  
  await browser.close();
  console.log('Done');
})();
