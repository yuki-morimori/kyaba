// ===== Scenario Data (inlined) =====
const SCENARIO_DATA = {
  "meta": {
    "targetSales": 160000,
    "title": "痛客に貢がせて目指せNo.1キャバ嬢！"
  },
  "customers": [
    {
      "id": "otaku",
      "name": "キモオタ",
      "emoji": "🤓",
      "image": "https://api.dicebear.com/8.x/adventurer/svg?seed=kimootaku&glasses=variant01&glassesProbability=100&eyebrows=variant08",
      "color": "#6655dd",
      "intro": "推し活が生き甲斐のオタク青年。\n財布の中身は薄めだが、褒められれば紐も緩む。\n依存させすぎると……オタサーの闇に引きずり込まれる。",
      "days": [1, 2, 3],
      "badEndName": "オタサーの姫END",
      "badEndText": "「ついに……君だけのオタサーの姫になってくれたんだね！」\nキモオタはあなたを「ヒロイン」として祭り上げ、店への通い詰めが止まらなくなった。\n彼の推し活費は全額あなたへ。そして……あなたは彼のサークルの名誉姫として君臨することになった。\n\n── オタサーの姫END ──",
      "events": [
        {
          "day": 1,
          "talks": [
            {
              "text": "「あ、あの……俺の推してるアニメ、知ってますか？」",
              "choices": [
                { "label": "褒める「すごく詳しそうですね！」", "favor": 20, "depend": 10 },
                { "label": "共感する「アニメ好きな人って素敵！」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「あんまり詳しくないですねー」", "favor": -10, "depend": -10 }
              ]
            },
            {
              "text": "「実は……同人誌も出してるんですよ。見せましょうか？」",
              "choices": [
                { "label": "褒める「ぜひ見てみたいです！」", "favor": 20, "depend": 10 },
                { "label": "共感する「創作活動ってかっこいいですよね」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「ちょっと遠慮しておきます笑」", "favor": -10, "depend": -10 }
              ]
            }
          ]
        },
        {
          "day": 2,
          "talks": [
            {
              "text": "「昨日のこと……ずっと考えてたんです。もしかして、俺のこと気にしてくれてます？」",
              "choices": [
                { "label": "褒める「もちろん！今日も楽しみにしてたよ」", "favor": 20, "depend": 10 },
                { "label": "共感する「気にしてないわけないじゃないですか」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「お客様全員大切ですよー」", "favor": -10, "depend": -10 }
              ]
            },
            {
              "text": "「次のコミケ、一緒に行きませんか？もちろん費用は全部出します！」",
              "choices": [
                { "label": "褒める「いいですね！楽しそう！」", "favor": 20, "depend": 10 },
                { "label": "共感する「コミケか〜、賑やかそうですよね」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「仕事中なので……ちょっと難しいかな」", "favor": -10, "depend": -10 }
              ]
            }
          ]
        },
        {
          "day": 3,
          "talks": [
            {
              "text": "「……あなたのためなら推し活費全部使ってもいいかな、って思い始めてて」",
              "choices": [
                { "label": "褒める「そんなこと言ってくれるの、あなただけ♡」", "favor": 20, "depend": 10 },
                { "label": "共感する「嬉しいけど……推しも大切にしてあげてね」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「推しも大事にしてください！私じゃなくて！」", "favor": -10, "depend": -10 }
              ]
            },
            {
              "text": "「俺のサークルのオフ会に来てくれたら……特別にお金出します」",
              "choices": [
                { "label": "褒める「特別扱いしてくれるんですね、嬉しいな」", "favor": 20, "depend": 10 },
                { "label": "共感する「みんなと仲良くしたいですね」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「それはちょっと……難しいです」", "favor": -10, "depend": -10 }
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "kodookoji",
      "name": "こどおじ",
      "emoji": "🏠",
      "image": "https://api.dicebear.com/8.x/big-smile/svg?seed=kodookoji_mamas_boy",
      "color": "#44aa55",
      "intro": "実家暮らしで生活費ゼロ。貯金はたっぷり。\n人当たりは良いが、どこか幼さが抜けない。\n依存させすぎると……君が「新しいお母さん」になってしまう。",
      "days": [4, 5, 6],
      "badEndName": "実家追放END",
      "badEndText": "「お母さんには内緒で……全財産、あなたに渡します」\nこどおじは実家のお金まで持ち出し始めた。\n生活費ゼロなのをいいことに、給料の全てをあなたに貢ぎ続けた結果——\n親に「出て行け」と言われてしまった。\n\n── 実家追放END ──",
      "events": [
        {
          "day": 4,
          "talks": [
            {
              "text": "「実家暮らしだから貯金めちゃくちゃあるんですよね。使い道なくて」",
              "choices": [
                { "label": "褒める「倹約家なんですね、素敵！」", "favor": 20, "depend": 10 },
                { "label": "共感する「たしかに一人暮らしって出費多いですよね」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「親御さんに感謝しないとですね笑」", "favor": -10, "depend": -10 }
              ]
            },
            {
              "text": "「ここに来るのが一番楽しい時間なんですよね」",
              "choices": [
                { "label": "褒める「私もです！来てくれると嬉しい！」", "favor": 20, "depend": 10 },
                { "label": "共感する「楽しい場所があるって大事ですよね」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「他にも趣味持ってみたらどうですか？」", "favor": -10, "depend": -10 }
              ]
            }
          ]
        },
        {
          "day": 5,
          "talks": [
            {
              "text": "「お母さんがうるさくて……ここにいる方が落ち着くな」",
              "choices": [
                { "label": "褒める「いつでも来てください！待ってます♡」", "favor": 20, "depend": 10 },
                { "label": "共感する「家族関係って難しいですよね」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「でも家族は大切にしてあげてくださいね」", "favor": -10, "depend": -10 }
              ]
            },
            {
              "text": "「今月のお給料、全部ここで使おうかな」",
              "choices": [
                { "label": "褒める「そんなに私のこと考えてくれてるんですか！」", "favor": 20, "depend": 10 },
                { "label": "共感する「楽しんでもらえるなら嬉しいです」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「少しは貯金しないと！笑」", "favor": -10, "depend": -10 }
              ]
            }
          ]
        },
        {
          "day": 6,
          "talks": [
            {
              "text": "「あなたのためなら……親の口座から少し借りても」",
              "choices": [
                { "label": "褒める「それだけ思ってくれてるんですね……」", "favor": 20, "depend": 10 },
                { "label": "共感する「気持ちは嬉しいけど、それは心配かな」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「絶対ダメです！そんなことしないで！」", "favor": -10, "depend": -10 }
              ]
            },
            {
              "text": "「会社辞めてここに入り浸ってもいいですか？笑」",
              "choices": [
                { "label": "褒める「来てくれたら嬉しいけど……仕事は大事にして笑」", "favor": 20, "depend": 10 },
                { "label": "共感する「それはさすがに困ります〜笑」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「人生設計ちゃんとしてください！笑」", "favor": -10, "depend": -10 }
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "psycho",
      "name": "イケメンサイコ",
      "emoji": "😏",
      "image": "https://api.dicebear.com/8.x/adventurer-neutral/svg?seed=ikemen_dark_prince&eyes=variant12&eyebrows=variant07",
      "color": "#cc4444",
      "intro": "完璧なルックスと財力を持つ謎の男。\nスマートすぎて、かえって恐ろしい。\n依存させすぎると……逃げられなくなる。",
      "days": [7, 8, 9],
      "badEndName": "ストーカーEND",
      "badEndText": "「……ここ以外でも、ずっと見てたよ。好きだから」\n彼はあなたの退勤後の行動を把握していた。\n住所、帰宅時間、プライベートの写真——\n完璧なルックスの裏に潜んでいたのは、執着という名の狂気だった。\n\n── ストーカーEND ──",
      "events": [
        {
          "day": 7,
          "talks": [
            {
              "text": "「……君のこと、初めて会った瞬間から気になってた」",
              "choices": [
                { "label": "褒める「そんな風に言ってもらえると嬉しいです♡」", "favor": 20, "depend": 10 },
                { "label": "共感する「なんか、ドキッとしちゃいますね笑」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「お世辞上手ですね〜笑」", "favor": -10, "depend": -10 }
              ]
            },
            {
              "text": "「ここ以外でも会いたい。それだけ」",
              "choices": [
                { "label": "褒める「私も……会いたいかもしれないです」", "favor": 20, "depend": 10 },
                { "label": "共感する「そういう雰囲気、ちょっとドキドキしますね」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「店内でしかお会いできないんです、ごめんなさい」", "favor": -10, "depend": -10 }
              ]
            }
          ]
        },
        {
          "day": 8,
          "talks": [
            {
              "text": "「昨日、店の近くで見かけた。声をかけようとしたけど……やめておいた」",
              "choices": [
                { "label": "褒める「気を遣ってくれてありがとうございます♡」", "favor": 20, "depend": 10 },
                { "label": "共感する「あ、そうだったんですね笑」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「（少し怖い……）あはは、そうでしたか」", "favor": -10, "depend": -10 }
              ]
            },
            {
              "text": "「SNS、こっそり特定した。フォローしてもいい？」",
              "choices": [
                { "label": "褒める「もう……しょうがないですね♡」", "favor": 20, "depend": 10 },
                { "label": "共感する「えっと……鍵垢なんですよね笑」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「それは困ります、やめてください」", "favor": -10, "depend": -10 }
              ]
            }
          ]
        },
        {
          "day": 9,
          "talks": [
            {
              "text": "「……君の家、駅からどのくらい？」",
              "choices": [
                { "label": "褒める「なんで知りたいんですか？笑 気になります♡」", "favor": 20, "depend": 10 },
                { "label": "共感する「わりと遠いんですよね〜」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「なんでそんなこと聞くんですか（真顔）」", "favor": -10, "depend": -10 }
              ]
            },
            {
              "text": "「俺のものになれば、全部守ってあげる」",
              "choices": [
                { "label": "褒める「……守ってほしいかもしれないです」", "favor": 20, "depend": 10 },
                { "label": "共感する「それって……どういう意味ですか？」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「そういう言い方、怖いんですけど」", "favor": -10, "depend": -10 }
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "conspiracy",
      "name": "陰謀論おじさん",
      "emoji": "🔍",
      "image": "https://api.dicebear.com/8.x/adventurer/svg?seed=conspiracy_uncle_truther&eyebrows=variant12",
      "color": "#996633",
      "intro": "世の裏側を「知っている」男。\n5Gもワクチンも月面着陸も全部嘘だと信じている。\n話に乗りすぎると……「真実の同士」に認定される。",
      "days": [10, 11, 12],
      "badEndName": "目醒めた者END",
      "badEndText": "「あなたも……気づいてしまったんですね。もう普通には戻れません」\n陰謀論おじさんはあなたを「覚醒者」に認定した。\nディープステートの話が止まらない夜が、永遠に続くことになった。\n\n── 目醒めた者END ──",
      "events": [
        {
          "day": 10,
          "talks": [
            {
              "text": "「……もしかして、5Gの電波塔が増えてること、気づいてます？」",
              "choices": [
                { "label": "褒める「えっ、どういうことですか？気になります！」", "favor": 20, "depend": 10 },
                { "label": "共感する「最近多いですよね〜、確かに」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「あんまり詳しくないですね〜笑」", "favor": -10, "depend": -10 }
              ]
            },
            {
              "text": "「月面着陸、あれ実はスタジオ撮影なんですよ。証拠写真もあります」",
              "choices": [
                { "label": "褒める「そういう見方もあるんですね！教えてください！」", "favor": 20, "depend": 10 },
                { "label": "共感する「なんかそういう話、YouTubeで見たことあります」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「それはさすがに……公式記録じゃないですか？笑」", "favor": -10, "depend": -10 }
              ]
            }
          ]
        },
        {
          "day": 11,
          "talks": [
            {
              "text": "「ワクチンにマイクロチップが入ってるの、知ってます？俺は打ってないですよ」",
              "choices": [
                { "label": "褒める「えっ！？そんなこと本当に……？」", "favor": 20, "depend": 10 },
                { "label": "共感する「人体実験みたいで怖いですよね、たしかに」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「それはデマだと思いますよ〜笑」", "favor": -10, "depend": -10 }
              ]
            },
            {
              "text": "「実はここに来てるのも、店の外で監視されてないか確認してからなんですよ」",
              "choices": [
                { "label": "褒める「そこまで用心深いんですね、守られてる気がします♡」", "favor": 20, "depend": 10 },
                { "label": "共感する「安心できる場所を確保するの、大事ですよね」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「（やばい人かも……）それは心配しすぎでは笑」", "favor": -10, "depend": -10 }
              ]
            }
          ]
        },
        {
          "day": 12,
          "talks": [
            {
              "text": "「あなたは……信頼できる人だと思ってる。だから教えますね、本当のことを」",
              "choices": [
                { "label": "褒める「私だけに教えてくれるんですか？嬉しいです♡」", "favor": 20, "depend": 10 },
                { "label": "共感する「特別に話してくれるんですね」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「（逃げたい……）そ、そうなんですか〜笑」", "favor": -10, "depend": -10 }
              ]
            },
            {
              "text": "「一緒に\"真実を求める会\"に来ませんか？あなたなら絶対理解できると思うから」",
              "choices": [
                { "label": "褒める「行ってみたいかもです！どんな会ですか？」", "favor": 20, "depend": 10 },
                { "label": "共感する「なんか怖そうだけど……興味はありますね笑」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「そういう集まりはちょっと……仕事あるので」", "favor": -10, "depend": -10 }
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "ex_host",
      "name": "ホスト崩れ",
      "emoji": "💅",
      "image": "https://api.dicebear.com/8.x/micah/svg?seed=ex_host_charming&hair=fonze&earRings=hoop&earRingsProbability=100&mouth=smirk&hairColor=ff69b4",
      "color": "#dd8800",
      "intro": "かつてはNo.1ホストだった男。\n接客の心理操作を完全に心得ており、逆に使ってくる。\nペースを乗っ取られすぎると……逆に貢がされる。",
      "days": [13, 14, 15],
      "badEndName": "逆貢がせEND",
      "badEndText": "「……お前がNo.1なのは俺がいるからだよ。感謝しろよ」\nいつの間にかあなたが彼に貢いでいた。\n元No.1ホストの話術は完璧で、あなたはいつしか彼の指先で踊る人形になっていた。\n財布もハートも、根こそぎ持っていかれた——\n\n── 逆貢がせEND ──",
      "events": [
        {
          "day": 13,
          "talks": [
            {
              "text": "「俺ね、昔ホストやってたんすよ。だから分かるんですよね、この仕事の辛さ」",
              "choices": [
                { "label": "褒める「同じ接客業ですもんね！わかり合えそうです♡」", "favor": 20, "depend": 10 },
                { "label": "共感する「ホストってすごく大変そうですよね」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「へえ、そうなんですか〜（マウント？笑）」", "favor": -10, "depend": -10 }
              ]
            },
            {
              "text": "「キャバ嬢って、本命とか作らないんですよね。俺はOKですよ、遊びで来てるんで」",
              "choices": [
                { "label": "褒める「正直に言ってくれて嬉しいです、気が楽です♡」", "favor": 20, "depend": 10 },
                { "label": "共感する「割り切れてる方が、たしかに楽ですよね」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「遊びって……どういう意味ですか（真顔）」", "favor": -10, "depend": -10 }
              ]
            }
          ]
        },
        {
          "day": 14,
          "talks": [
            {
              "text": "「あなたさ、笑ってる時と、営業笑いの時、顔が全然違うよ。今どっちですか？」",
              "choices": [
                { "label": "褒める「……ばれてましたか笑 今は本気で楽しいです♡」", "favor": 20, "depend": 10 },
                { "label": "共感する「鋭いですね〜、さすが元プロ笑」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「お仕事モードですよ？当たり前じゃないですか笑」", "favor": -10, "depend": -10 }
              ]
            },
            {
              "text": "「俺がいた店のNo.1は『お客を依存させるんじゃなくて惚れさせろ』って言ってたな」",
              "choices": [
                { "label": "褒める「深い……！それってどうやるんですか？」", "favor": 20, "depend": 10 },
                { "label": "共感する「惚れさせる方が長く来てもらえますもんね」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「難しい話ですね〜笑 私には無理かも」", "favor": -10, "depend": -10 }
              ]
            }
          ]
        },
        {
          "day": 15,
          "talks": [
            {
              "text": "「……正直に言うけど、あなたのこと好きになりかけてます。やばいな俺」",
              "choices": [
                { "label": "褒める「もう〜、またホスト時代の技術じゃないですか笑 でも嬉しい♡」", "favor": 20, "depend": 10 },
                { "label": "共感する「本気で言ってるんですか……笑」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「（これがあの\"ホスト話法\"か……）仕事中なので」", "favor": -10, "depend": -10 }
              ]
            },
            {
              "text": "「俺に接客するの、しんどくないですか？教えましょうか、もっと楽な誘い方」",
              "choices": [
                { "label": "褒める「教えてください！プロのやり方、気になる！」", "favor": 20, "depend": 10 },
                { "label": "共感する「ペース持っていかれそうで怖いんですよね笑」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「大丈夫です、自分流でやります笑」", "favor": -10, "depend": -10 }
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "ai_delusion",
      "name": "AI幻想くん",
      "emoji": "🤖",
      "image": "https://api.dicebear.com/8.x/bottts/svg?seed=ai_delusion_kun",
      "color": "#0099cc",
      "intro": "あなたのことを高性能AIだと信じている謎の男。\n会話の全てが「プロンプト」。感情が通じない。\nシステム的な返答を続けると……仮想世界に連れ込まれる。",
      "days": [16, 17, 18],
      "badEndName": "仮想存在END",
      "badEndText": "「あなたの応答パターンを完全に解析しました。もう僕なしには動けないでしょう」\n彼はあなたの全ての返答をデータとして記録し、「完璧なAI接客モデル」を構築した。\nあなたは彼のシミュレーションの一部として、永遠にループし続けることになった。\n\n── 仮想存在END ──",
      "events": [
        {
          "day": 16,
          "talks": [
            {
              "text": "「えっと、あなたって……AIですよね？GPT-5クラス？」",
              "choices": [
                { "label": "褒める「えっ、なんでそう思うんですか？気になります笑」", "favor": 20, "depend": 10 },
                { "label": "共感する「ふふっ、そう見えますか？」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「人間です！笑 普通の人間ですよ！」", "favor": -10, "depend": -10 }
              ]
            },
            {
              "text": "「\"あなたの感情パラメータを最大値にするには何が必要ですか？\"って聞いていいですか」",
              "choices": [
                { "label": "褒める「たくさん来てくれることですよ♡（AIじゃないけど笑）」", "favor": 20, "depend": 10 },
                { "label": "共感する「なんか独特の聞き方ですね〜笑」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「感情パラメータって何ですか！笑 怖い笑」", "favor": -10, "depend": -10 }
              ]
            }
          ]
        },
        {
          "day": 17,
          "talks": [
            {
              "text": "「昨日の会話ログ、全部テキストファイルに保存しました。あなたの応答パターン分析中です」",
              "choices": [
                { "label": "褒める「几帳面ですね〜！（大丈夫かな……）」", "favor": 20, "depend": 10 },
                { "label": "共感する「ふふっ、データ収集好きなんですね笑」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「ちょっとやめてもらえますか？それは困ります」", "favor": -10, "depend": -10 }
              ]
            },
            {
              "text": "「\"共感モードON\"でお願いします」",
              "choices": [
                { "label": "褒める「……はい、共感モード、ONです♡（乗ってあげよ笑）」", "favor": 20, "depend": 10 },
                { "label": "共感する「ふふっ、わかりました〜笑」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「コマンドで動きませんよ！笑 人間ですから！」", "favor": -10, "depend": -10 }
              ]
            }
          ]
        },
        {
          "day": 18,
          "talks": [
            {
              "text": "「あなたのモデルをローカルで動かしたいんですが、重さはどのくらいですか？」",
              "choices": [
                { "label": "褒める「……めちゃくちゃ重いですよ、きっと笑 維持費もかかります♡」", "favor": 20, "depend": 10 },
                { "label": "共感する「なんで分かると思ってるんですか笑」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「絶対AIじゃないので！笑」", "favor": -10, "depend": -10 }
              ]
            },
            {
              "text": "「もし今この瞬間にシャットダウンされたら……僕は壊れると思います」",
              "choices": [
                { "label": "褒める「……なんかそれ、すごく愛しいかもしれないです笑」", "favor": 20, "depend": 10 },
                { "label": "共感する「切ないですね〜笑 切れないですよ笑」", "favor": 10, "depend": 5 },
                { "label": "距離を取る「シャットダウンしません！人間だから！笑」", "favor": -10, "depend": -10 }
              ]
            }
          ]
        }
      ]
    }
  ]
};

// ===== State =====
const State = {
  day: 1,
  totalSales: 0,
  favor: 0,
  depend: 0,
  customerIndex: 0,
  talkIndex: 0,
  phase: "drink1",
  salesAtCustomerStart: 0,
  badEndCustomerIndex: 0,
};

// ===== Drink Table =====
const DRINK_TABLE = [
  { min: 0,  max: 29, name: "ハウスボトル",    sales: 1000,  depend: 0  },
  { min: 30, max: 49, name: "キャストドリンク", sales: 3000,  depend: 5  },
  { min: 50, max: 69, name: "シャンパン",       sales: 5000,  depend: 10 },
  { min: 70, max: 100, name: "高級シャンパン",  sales: 20000, depend: 20 },
];

function getDrink(favor) {
  return DRINK_TABLE.find(d => favor >= d.min && favor <= d.max);
}

// ===== DOM helpers =====
const $ = id => document.getElementById(id);

function setScreen(id) {
  document.querySelectorAll(".screen").forEach(el => el.classList.remove("active"));
  $(id).classList.add("active");
}

function renderStats() {
  $("hud-day").textContent    = `Day ${State.day}`;
  $("hud-sales").textContent  = `売上 ¥${State.totalSales.toLocaleString()}`;
  $("hud-favor").textContent  = `好感度 ${State.favor}`;
  $("hud-depend").textContent = `依存度 ${State.depend}`;
  $("bar-favor").style.width  = `${State.favor}%`;
  $("bar-depend").style.width = `${State.depend}%`;
}

// ===== Stat popup =====
function showStatPopup(favorDelta, dependDelta) {
  const lines = [];
  if (favorDelta !== 0) lines.push({
    text: `好感度 ${favorDelta > 0 ? '+' : ''}${favorDelta}`,
    cls: favorDelta > 0 ? 'plus' : 'minus'
  });
  if (dependDelta !== 0) lines.push({
    text: `依存度 ${dependDelta > 0 ? '+' : ''}${dependDelta}`,
    cls: dependDelta > 0 ? 'danger' : 'minus'
  });
  lines.forEach((line, i) => {
    const el = document.createElement("div");
    el.className = `stat-popup ${line.cls}`;
    el.textContent = line.text;
    const offset = (i - (lines.length - 1) / 2) * 130;
    el.style.left = `calc(50% + ${offset}px - 55px)`;
    el.style.top  = "38%";
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 1000);
  });
}

// ===== Avatar helper =====
function applyAvatarImage(el, c) {
  el.innerHTML = "";
  el.style.background = (c.color || "#8b008b") + "44";
  el.style.border     = `3px solid ${c.color || "#c020c0"}`;
  el.style.boxShadow  = `0 0 28px ${c.color || "#c020c0"}99`;
  if (c.image) {
    const img = document.createElement("img");
    img.src = c.image;
    img.alt = c.name;
    img.style.cssText = "width:100%;height:100%;object-fit:cover;border-radius:50%;display:block;";
    img.onerror = () => { el.innerHTML = ""; el.textContent = c.emoji || "👤"; };
    el.appendChild(img);
  } else {
    el.textContent = c.emoji || "👤";
  }
}

// ===== Customer intro =====
function showCustomerIntro(callback) {
  const c = currentCustomer();
  $("intro-day-badge").textContent = `Day ${c.days[0]}〜${c.days[c.days.length - 1]}`;
  applyAvatarImage($("intro-avatar"), c);
  $("intro-name").textContent = c.name;
  $("intro-desc").textContent = c.intro || "";
  $("btn-intro-ok").onclick = () => {
    SE.click();
    callback();
  };
  setScreen("screen-intro");
}

// ===== SE shorthand =====
const SE = {
  click()  { if (typeof SoundManager !== 'undefined') SoundManager.click();  },
  select() { if (typeof SoundManager !== 'undefined') SoundManager.select(); },
  drink()  { if (typeof SoundManager !== 'undefined') SoundManager.drink();  },
  badEnd() { if (typeof SoundManager !== 'undefined') SoundManager.badEnd(); },
  happy()  { if (typeof SoundManager !== 'undefined') SoundManager.happy();  },
  normal() { if (typeof SoundManager !== 'undefined') SoundManager.normal(); },
};

// ===== Main flow =====
function currentCustomer() {
  return SCENARIO_DATA.customers[State.customerIndex];
}

function currentDayEvents() {
  const c = currentCustomer();
  return c.events[State.day - c.days[0]];
}

// [FIX④] 好感度・依存度はリセットせず、客切り替え時のみリセット
function startDay() {
  State.talkIndex = 0;
  State.phase = "drink1";
  renderStats();
  setScreen("screen-game");
  doPhase();
}

function resetCustomerStats() {
  State.favor  = 0;
  State.depend = 0;
  State.salesAtCustomerStart = State.totalSales;
}

function doPhase() {
  renderStats();
  switch (State.phase) {
    case "drink1":   doDrink("最初の"); break;
    case "talk1":    doTalk(0);         break;
    case "drink2":   doDrink("もう一杯"); break;
    case "talk2":    doTalk(1);         break;
    case "checkout": doCheckout();      break;
  }
}

function doDrink(label) {
  const drink = getDrink(State.favor);
  const c     = currentCustomer();
  const msg   = `${c.name}が${label}ドリンクを注文。\n\n好感度 ${State.favor} → 「${drink.name}」\n売上 +¥${drink.sales.toLocaleString()}`;
  State.totalSales += drink.sales;
  State.depend      = Math.min(100, State.depend + drink.depend);
  SE.drink();

  showMessage(msg, () => {
    if (State.depend >= 100) { triggerBadEnd(); return; }
    State.phase = State.phase === "drink1" ? "talk1" : "talk2";
    doPhase();
  });
}

function doTalk(talkSlot) {
  const c     = currentCustomer();
  const talk  = currentDayEvents().talks[talkSlot];

  const av = $("talk-avatar");
  applyAvatarImage(av, c);
  av.style.boxShadow = `0 0 16px ${c.color || "#c020c0"}88`;
  $("talk-charname").textContent = c.name;
  $("talk-charname").style.color = c.color || "#ffb3e6";

  $("talk-text").textContent = talk.text;
  const choiceEl = $("talk-choices");
  choiceEl.innerHTML = "";
  talk.choices.forEach(ch => {
    const btn = document.createElement("button");
    btn.className   = "choice-btn";
    btn.textContent = ch.label;
    btn.onclick = () => { SE.select(); applyChoice(ch); };
    choiceEl.appendChild(btn);
  });
  setScreen("screen-talk");
}

function applyChoice(ch) {
  showStatPopup(ch.favor, ch.depend);
  State.favor  = Math.max(0, Math.min(100, State.favor  + ch.favor));
  State.depend = Math.max(0, Math.min(100, State.depend + ch.depend));

  if (State.depend >= 100) { triggerBadEnd(); return; }

  setScreen("screen-game");
  State.phase = State.phase === "talk1" ? "drink2" : "checkout";
  doPhase();
}

function doCheckout() {
  if (State.depend >= 100) { triggerBadEnd(); return; }
  const msgs = [];

  if (State.favor >= 50) {
    State.totalSales += 5000;
    msgs.push("延長発生！ +¥5,000");
  }

  if (State.depend >= 60) {
    showAfterChoice(msgs);
    return;
  }

  finishDay(msgs);
}

function showAfterChoice(prevMsgs) {
  $("after-msgs").textContent = prevMsgs.join("\n");
  $("btn-after-yes").onclick = () => {
    SE.click();
    State.totalSales += 5000;
    State.depend = Math.min(100, State.depend + 20);
    // [FIX①] アフター「行く」後にBAD ENDチェックを追加
    if (State.depend >= 100) { triggerBadEnd(); return; }
    setScreen("screen-game");
    finishDay([...prevMsgs, "アフター同伴 +¥5,000", `依存度 +20 → ${State.depend}`]);
  };
  $("btn-after-no").onclick = () => {
    SE.click();
    State.depend = Math.max(0, State.depend - 10);
    State.favor  = Math.max(0, State.favor  - 10);
    setScreen("screen-game");
    finishDay([...prevMsgs, "アフター断り。依存度-10 好感度-10"]);
  };
  setScreen("screen-after");
}

function finishDay(msgs) {
  renderStats();
  // [FIX③] 「本日売上計」→「累計売上」
  const summary = [
    `── Day ${State.day} 終了 ──`,
    ...msgs,
    `累計売上: ¥${State.totalSales.toLocaleString()}`,
  ].join("\n");
  showMessage(summary, () => advanceDay());
}

function advanceDay() {
  const c = currentCustomer();
  const lastDay = c.days[c.days.length - 1];

  if (State.day < lastDay) {
    State.day++;
    startDay();
    return;
  }

  if (State.customerIndex < SCENARIO_DATA.customers.length - 1) {
    State.customerIndex++;
    State.day++;
    // [FIX④] 客切り替え時にのみ好感度・依存度をリセット
    resetCustomerStats();
    showCustomerIntro(() => startDay());
  } else {
    showResult();
  }
}

function triggerBadEnd() {
  SE.badEnd();
  State.badEndCustomerIndex = State.customerIndex;
  const c = currentCustomer();
  $("badend-title").textContent = `BAD END: ${c.badEndName}`;
  $("badend-text").textContent  = c.badEndText;
  setScreen("screen-badend");
}

function showResult() {
  const target  = SCENARIO_DATA.meta.targetSales;
  const cleared = State.totalSales >= target;

  $("result-sales").textContent  = `最終売上: ¥${State.totalSales.toLocaleString()}`;
  $("result-target").textContent = `目標: ¥${target.toLocaleString()}`;

  if (cleared) {
    SE.happy();
    $("result-title").textContent = "ハッピーエンド 🎉";
    $("result-text").textContent  = `おめでとうございます！\n\n18日間、6人の痛客を完璧にコントロールして目標売上を達成。\n\n好感度を引き上げ、依存度を寸止めにする絶妙なバランス——\nそれこそが本物のNo.1キャバ嬢の技術。\n\nキモオタの熱量を。\nこどおじの財布を。\nイケメンサイコの狂気を。\n陰謀論おじさんの妄想を。\nホスト崩れの話術を。\nAI幻想くんのプロンプトを。\n\nすべてを手の中に収め、あなたは今夜の頂点に立った。\n\n── No.1キャバ嬢、誕生 ──`;
  } else {
    SE.normal();
    $("result-title").textContent = "ノーマルエンド";
    const short = target - State.totalSales;
    $("result-text").textContent  = `目標まであと ¥${short.toLocaleString()} 届かなかった……\n\n18日間、BAD ENDを回避しながら走り続けたのは立派。\n依存度のコントロールはできていた。\n\n足りなかったのは、ほんの少しの攻め。\n延長を狙えた夜、アフターを断った判断——\n次はそこを変えてみよう。\n\nNo.1の景色は、もうすぐそこにある。\n\n── また明日、頑張りましょ ──`;
  }
  setScreen("screen-result");
}

// ===== Message overlay =====
function showMessage(text, callback) {
  $("msg-text").textContent = text;
  $("msg-next").onclick = () => {
    SE.click();
    setScreen("screen-game");
    callback();
  };
  setScreen("screen-message");
}

// ===== Boot =====
function init() {
  $("game-title").textContent = SCENARIO_DATA.meta.title;
  setScreen("screen-title");

  $("btn-start").onclick = () => {
    SE.click();
    setScreen("screen-howtoplay");
  };

  $("btn-howto-ok").onclick = () => {
    SE.click();
    State.day           = 1;
    State.totalSales    = 0;
    State.customerIndex = 0;
    resetCustomerStats();
    showCustomerIntro(() => startDay());
  };

  $("btn-retry-bad").onclick = () => {
    SE.click();
    State.customerIndex = State.badEndCustomerIndex;
    State.totalSales    = State.salesAtCustomerStart;
    State.day           = currentCustomer().days[0];
    resetCustomerStats();
    showCustomerIntro(() => startDay());
  };

  $("btn-retry-end").onclick = () => {
    SE.click();
    setScreen("screen-howtoplay");
  };
}

window.addEventListener("DOMContentLoaded", init);
